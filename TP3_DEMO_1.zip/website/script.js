// --- DONNEES : UNIVERSITES ---
const universites = [
    {
        id: "TU-BRAUNSCHWEIG",
        nom: "TU Braunschweig",
        pays: "Allemagne",
        climat: "TEMPERE", // Ou FROID selon interprétation, mis TEMPERE pour matcher R4/R11
        cout: "MOYEN",
        langues: { anglaisMin: "NIL", espagnolMin: "NIL", allemandMin: "B1" }, // Demande B1/B2 allemand
        branchesOK: ["GB", "GP", "IM", "GSU"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"],
        dureeMinDD: 18 // Spécifique R19
    },
    {
        id: "POLY-MTL",
        nom: "Polytechnique Montréal",
        pays: "Canada",
        climat: "FROID",
        cout: "MOYEN", // Ou ELEVE
        langues: { anglaisMin: "B2", espagnolMin: "NIL", allemandMin: "NIL" },
        branchesOK: ["GI", "IM", "GSU", "GP", "GM", "GB"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"]
    },
    {
        id: "SHERBROOKE",
        nom: "Université de Sherbrooke",
        pays: "Canada",
        climat: "FROID",
        cout: "MOYEN",
        langues: { anglaisMin: "NIL", espagnolMin: "NIL", allemandMin: "NIL" }, // Francophone
        branchesOK: ["GSU"], // R9
        objectifsOK: ["SEMESTRE"]
    },
    {
        id: "KTH",
        nom: "KTH Royal Institute of Technology",
        pays: "Suède",
        climat: "FROID",
        cout: "ELEVE",
        langues: { anglaisMin: "B2", espagnolMin: "NIL", allemandMin: "NIL" },
        branchesOK: ["GI", "IM"],
        objectifsOK: ["SEMESTRE"]
    },
    {
        id: "AALTO",
        nom: "Aalto University",
        pays: "Finlande",
        climat: "FROID",
        cout: "ELEVE",
        langues: { anglaisMin: "B2", espagnolMin: "NIL", allemandMin: "NIL" },
        branchesOK: ["GI", "IM"],
        objectifsOK: ["SEMESTRE"]
    },
    {
        id: "UPC",
        nom: "UPC Barcelona",
        pays: "Espagne",
        climat: "CHAUD",
        cout: "FAIBLE", // R12
        langues: { anglaisMin: "NIL", espagnolMin: "B1", allemandMin: "NIL" },
        branchesOK: ["GI", "IM", "GSU", "GP", "GM", "GB"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"]
    },
    {
        id: "UTFPR",
        nom: "UTFPR",
        pays: "Brésil",
        climat: "CHAUD",
        cout: "FAIBLE",
        langues: { anglaisMin: "NIL", espagnolMin: "NIL", allemandMin: "NIL" }, // Portugais
        branchesOK: ["IM"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"]
    },
    {
        id: "CHIBA",
        nom: "Chiba University",
        pays: "Japon",
        climat: "TEMPERE",
        cout: "ELEVE",
        langues: { anglaisMin: "B2", espagnolMin: "NIL", allemandMin: "NIL" },
        branchesOK: ["GI", "IM"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"]
    },
    {
        id: "CRANFIELD",
        nom: "Cranfield University",
        pays: "Royaume-Uni",
        climat: "TEMPERE",
        cout: "ELEVE",
        langues: { anglaisMin: "C1", espagnolMin: "NIL", allemandMin: "NIL" }, // R5 LA13 ~ C1
        branchesOK: ["GM"],
        objectifsOK: ["SEMESTRE", "DOUBLE-DIPLOME"]
    },
    {
        id: "UQ",
        nom: "University of Queensland",
        pays: "Australie",
        climat: "CHAUD",
        cout: "ELEVE",
        langues: { anglaisMin: "B2", espagnolMin: "NIL", allemandMin: "NIL" },
        branchesOK: ["GI", "IM"],
        objectifsOK: ["SEMESTRE"]
    }
];

// --- UTILITAIRES ---

// Conversion niveau langue en valeur numérique pour comparaison
function getLangValue(level) {
    const levels = ["NIL", "A1", "A2", "B1", "B2", "C1", "C2"];
    return levels.indexOf(level);
}

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', () => {
    const select = document.getElementById('univ-target');
    universites.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = `${u.nom} (${u.pays})`;
        select.appendChild(opt);
    });
});

// --- LOGIQUE METIER ---

function getProfil() {
    return {
        branche: document.getElementById('branche').value,
        anglais: document.getElementById('anglais').value,
        allemand: document.getElementById('allemand').value,
        espagnol: document.getElementById('espagnol').value,
        budget: document.getElementById('budget').value,
        climat: document.getElementById('climat').value,
        objectif: document.getElementById('objectif').value,
        culture: document.getElementById('culture').value
    };
}

function evaluerUniversite(univ, profil) {
    let score = 0;
    let positifs = [];
    let limites = [];
    let exclu = false;

    // --- RÈGLES LINGUISTIQUES ---
    
    // R2: Si Anglais < B2, exclure USA/UK/Australie (anglophones stricts)
    if (getLangValue(profil.anglais) < getLangValue("B2")) {
        if (["USA", "Royaume-Uni", "Australie"].includes(univ.pays)) {
            exclu = true;
            limites.push("Niveau d'anglais insuffisant pour ce pays anglophone (B2 requis)");
        }
    }

    // R4: Si Allemand < B2, exclure Allemagne
    // Note: TU Braunschweig demande B1/B2. Si profil < B1, c'est sûr non.
    if (univ.pays === "Allemagne" && getLangValue(profil.allemand) < getLangValue("B1")) { // Simplification B1 min
        exclu = true;
        limites.push("Niveau d'allemand insuffisant pour l'Allemagne");
    }

    // R5: Cranfield demande C1 (LA13)
    if (univ.id === "CRANFIELD" && getLangValue(profil.anglais) < getLangValue("C1")) {
        exclu = true;
        limites.push("Cranfield exige un niveau d'anglais C1 (LA13)");
    }

    // Vérification générale des prérequis langue de l'université
    if (univ.langues.anglaisMin !== "NIL" && getLangValue(profil.anglais) < getLangValue(univ.langues.anglaisMin)) {
         // Déjà géré par R2/R5 mais au cas où
         limites.push(`Niveau d'anglais ${profil.anglais} insuffisant (requis ${univ.langues.anglaisMin})`);
         score -= 5;
    } else if (univ.langues.anglaisMin !== "NIL") {
        positifs.push("Niveau d'anglais suffisant");
        score += 2;
    }

    if (univ.langues.espagnolMin !== "NIL") {
        if (getLangValue(profil.espagnol) >= getLangValue(univ.langues.espagnolMin)) {
            positifs.push("Niveau d'espagnol suffisant");
            score += 2;
        } else {
            limites.push(`Niveau d'espagnol insuffisant (requis ${univ.langues.espagnolMin})`);
            score -= 5;
        }
    }

    if (univ.langues.allemandMin !== "NIL") {
        if (getLangValue(profil.allemand) >= getLangValue(univ.langues.allemandMin)) {
            positifs.push("Niveau d'allemand suffisant");
            score += 2;
        } 
        // Exclusion déjà gérée par R4
    }

    // --- RÈGLES BRANCHE ---
    // R7, R8, R9, R10, R11
    if (univ.branchesOK.includes(profil.branche)) {
        positifs.push(`Votre branche ${profil.branche} est acceptée dans ce partenariat`);
        score += 5;
    } else {
        limites.push(`Ce partenariat ne cible pas prioritairement la branche ${profil.branche}`);
        score -= 10;
        // On n'exclut pas forcément totalement, mais gros malus
    }

    // --- RÈGLES BUDGET ---
    // R12, R13, R14
    if (profil.budget === "FAIBLE") {
        if (["USA", "Australie"].includes(univ.pays)) { // R13
            limites.push("Budget faible incompatible avec le coût de la vie (USA/Australie)");
            score -= 10;
        } else if (univ.cout === "FAIBLE" || univ.cout === "MOYEN") { // R12 (Europe du sud/Est)
            positifs.push("Budget compatible avec le coût de la vie");
            score += 3;
        } else if (univ.cout === "ELEVE") {
            limites.push("Coût de la vie élevé pour un budget faible");
            score -= 5;
        }
    } else if (profil.budget === "MOYEN") {
        if (univ.cout === "ELEVE") {
            limites.push("Attention, coût de la vie élevé pour un budget moyen");
            score -= 2;
        } else {
            positifs.push("Budget compatible");
            score += 2;
        }
    } else if (profil.budget === "ELEVE") { // R14
        positifs.push("Budget confortable pour cette destination");
        score += 2;
    }

    // --- RÈGLES OBJECTIF ---
    // R15, R16, R17, R18, R19
    if (profil.objectif === "DOUBLE-DIPLOME") {
        if (!univ.objectifsOK.includes("DOUBLE-DIPLOME")) {
            exclu = true;
            limites.push("Cette université ne propose pas de Double Diplôme");
        } else {
            positifs.push("Double Diplôme possible");
            score += 5;
        }
    } else if (profil.objectif === "STAGE") {
        // R18: Préférence anglophone
        if (["Royaume-Uni", "USA", "Canada", "Australie", "Irlande"].includes(univ.pays) || univ.langues.anglaisMin !== "NIL") {
            positifs.push("Région anglophone adaptée pour un stage international");
            score += 3;
        }
    }

    // --- RÈGLES CLIMAT & CULTURE ---
    // R20, R21, R22
    if (profil.climat === univ.climat) {
        positifs.push(`Climat ${univ.climat.toLowerCase()} correspondant à votre préférence`);
        score += 3;
    } else {
        limites.push(`Le climat ${univ.climat} diffère de votre préférence (${profil.climat})`);
        score -= 1;
    }

    if (profil.culture === "ASIATIQUE" && ["Japon", "Chine", "Corée du Sud"].includes(univ.pays)) { // R22
        positifs.push("Correspond à votre préférence culturelle Asiatique");
        score += 4;
    }
    if (profil.culture === "LATINE" && ["Espagne", "Brésil", "Argentine", "Colombie", "Mexique"].includes(univ.pays)) {
        positifs.push("Correspond à votre préférence culturelle Latine");
        score += 4;
    }
    if (profil.culture === "NORDIQUE" && ["Suède", "Finlande", "Norvège", "Danemark"].includes(univ.pays)) {
        positifs.push("Correspond à votre préférence culturelle Nordique");
        score += 4;
    }

    // --- RETOUR ---
    if (exclu) score = -100; // Force low score

    return {
        univ: univ,
        score: score,
        positifs: positifs,
        limites: limites,
        exclu: exclu
    };
}

// --- MOTEUR D'AFFICHAGE ---

function renderResult(containerId, results, isForward) {
    const container = document.getElementById(containerId);
    container.innerHTML = "";

    if (results.length === 0) {
        container.textContent = "Aucun résultat.";
        return;
    }

    // Header
    let header = document.createElement('div');
    if (isForward) {
        if (results[0].score >= 10) {
            header.innerHTML = "<strong>--- DESTINATION IDEALE TROUVEE ---</strong><br><br>";
        } else {
            header.innerHTML = "<strong>--- AUCUNE DESTINATION PARFAITEMENT IDEALE ---</strong><br>Cependant, voici des universités que je peux tout de même vous proposer :<br><br>";
        }
    } else {
        header.innerHTML = `<strong>--- ANALYSE DE LA DESTINATION : ${results[0].univ.nom} (${results[0].univ.pays}) ---</strong><br><br>`;
    }
    container.appendChild(header);

    // Items
    const limit = isForward ? Math.min(results.length, 3) : 1;
    
    for (let i = 0; i < limit; i++) {
        const r = results[i];
        const div = document.createElement('div');
        div.style.marginBottom = "20px";

        if (isForward) {
            div.innerHTML += `<strong>${i+1}) ${r.univ.nom} (${r.univ.pays})</strong><br>`;
        }

        div.innerHTML += `Raisons positives :<br>`;
        if (r.positifs.length > 0) {
            r.positifs.forEach(p => div.innerHTML += `- ${p}<br>`);
        } else {
            div.innerHTML += `- Aucune raison spécifique détectée<br>`;
        }

        div.innerHTML += `Ce qui manque / limites :<br>`;
        if (r.limites.length > 0) {
            r.limites.forEach(l => div.innerHTML += `- ${l}<br>`);
        } else {
            div.innerHTML += `- Aucune contre-indication majeure détectée<br>`;
        }

        // Conclusion pour backward
        if (!isForward) {
            div.innerHTML += `<br>Conclusion :<br>`;
            if (r.exclu) {
                div.innerHTML += `Destination fortement déconseillée ou impossible (critères bloquants).`;
            } else if (r.score >= 10) {
                div.innerHTML += `Cette destination est globalement adaptée à votre profil, je peux la recommander.`;
            } else if (r.score > 0) {
                div.innerHTML += `Destination envisageable mais avec des compromis.`;
            } else {
                div.innerHTML += `Destination plutôt à éviter pour votre profil actuel.`;
            }
        }

        container.appendChild(div);
    }
    
    // Footer forward
    if (isForward) {
         const footer = document.createElement('div');
         if (results[0].score >= 10) {
             footer.innerHTML = "<br>Conclusion : cette université correspond très bien à votre profil.";
         } else {
             footer.innerHTML = "<br>Conclusion générale : vous n'avez pas encore un profil parfait pour une destination précise, mais ces options peuvent être intéressantes si vous acceptez certains compromis.";
         }
         container.appendChild(footer);
    }
}

// --- FONCTIONS PRINCIPALES ---

function chainageAvant() {
    const profil = getProfil();
    
    // Evaluer toutes les universités
    let resultats = universites.map(u => evaluerUniversite(u, profil));
    
    // Trier par score décroissant
    resultats.sort((a, b) => b.score - a.score);

    // Filtrer les exclusions totales si on a d'autres choix ? 
    // Pour l'instant on garde tout mais on les met à la fin via le tri score
    
    renderResult("forward-result", resultats, true);
}

function chainageArriere() {
    const profil = getProfil();
    const targetId = document.getElementById('univ-target').value;
    const univ = universites.find(u => u.id === targetId);

    if (!univ) return;

    const resultat = evaluerUniversite(univ, profil);
    renderResult("backward-result", [resultat], false);
}
